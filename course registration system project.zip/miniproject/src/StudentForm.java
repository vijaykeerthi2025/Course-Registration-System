/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
 import javax.swing.*;
import java.sql.*;
public class StudentForm extends JFrame {
     JTextField idField, nameField, emailField;

    public StudentForm() {
        setTitle("Student Registration");

        JLabel idLabel = new JLabel("Student ID:");
        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");

        idField = new JTextField();
        nameField = new JTextField();
        emailField = new JTextField();
        JButton nextBtn = new JButton("Next");

        idLabel.setBounds(30, 30, 100, 30);
        nameLabel.setBounds(30, 70, 100, 30);
        emailLabel.setBounds(30, 110, 100, 30);

        idField.setBounds(140, 30, 150, 30);
        nameField.setBounds(140, 70, 150, 30);
        emailField.setBounds(140, 110, 150, 30);
        nextBtn.setBounds(140, 160, 100, 30);

        add(idLabel); add(idField);
        add(nameLabel); add(nameField);
        add(emailLabel); add(emailField);
        add(nextBtn);

        nextBtn.addActionListener(e -> saveStudent());

        setSize(350, 250);
        setLayout(null);
        setVisible(true);
    }

    void saveStudent() {
        String id = idField.getText();
        String name = nameField.getText();
        String email = emailField.getText();

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi")) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO student (student_id, name, email) VALUES (?, ?, ?)");
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, email);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Student registered successfully");
            new CourseSelection(id);
            // Pass student ID to course selection
            
            dispose();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}

