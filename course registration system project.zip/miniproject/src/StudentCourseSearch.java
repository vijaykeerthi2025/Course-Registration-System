/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
public class StudentCourseSearch extends JFrame {
   
 
    JTextField searchField;
    JPanel resultPanel;
    String studentId;

    public StudentCourseSearch(String studentId) {
        this.studentId = studentId;
        setTitle("Course Search");
        setSize(800, 600);
        setLayout(new BorderLayout());

        searchField = new JTextField(30);
        JButton searchBtn = new JButton("Search");
        searchBtn.addActionListener(e -> searchCourses());

        JPanel top = new JPanel();
        top.add(new JLabel("Search Course:"));
        top.add(searchField);
        top.add(searchBtn);
        add(top, BorderLayout.NORTH);

        resultPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        add(new JScrollPane(resultPanel), BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    void searchCourses() {
        resultPanel.removeAll();
        String query = searchField.getText();
        String sql = "SELECT * FROM courses WHERE title LIKE ? OR course_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + query + "%");
            pst.setString(2, query);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String courseId = rs.getString("course_id");
                String title = rs.getString("course_name");
                String instructor = rs.getString("instructor");
                String duration = rs.getString("duration");
                String desc = rs.getString("description");
                String imagePath = rs.getString("image_path");

                JPanel card = new JPanel();
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBorder(BorderFactory.createLineBorder(Color.GRAY));

                card.add(new JLabel(new ImageIcon(imagePath)));
                card.add(new JLabel("Title: " + title));
                card.add(new JLabel("Instructor: " + instructor));
                card.add(new JLabel("Duration: " + duration));

                JButton registerBtn = new JButton("Register");
                registerBtn.addActionListener(e -> registerCourse(courseId));
                card.add(registerBtn);
                
                resultPanel.add(card);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        resultPanel.revalidate();
        resultPanel.repaint();
    }

    void registerCourse(String courseId) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)")) {
            pst.setString(1, studentId);
            pst.setString(2, courseId);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Course registered successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new StudentCourseSearch("1"); // example student ID
    }
}
    

