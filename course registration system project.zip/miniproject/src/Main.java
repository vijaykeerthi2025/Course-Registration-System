/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
import javax.swing.*;
public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Course Registration System");
        JButton adminBtn = new JButton("Admin");
        JButton studentBtn = new JButton("Student");

        adminBtn.setBounds(100, 100, 120, 30);
        studentBtn.setBounds(250, 100, 120, 30);

        frame.add(adminBtn);
        frame.add(studentBtn);

        adminBtn.addActionListener(e -> {
            AdminLogin login = new AdminLogin();
            login.setVisible(true);
        });
        studentBtn.addActionListener(e -> new StudentForm());

        frame.setSize(500, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
    

