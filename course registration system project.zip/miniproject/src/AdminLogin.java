/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
import javax.swing.*;
import java.sql.*;
public class AdminLogin extends JFrame{
     JTextField userField;
    JPasswordField passField;

    public AdminLogin() {
        setTitle("Admin Login");
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");

        userField = new JTextField();
        passField = new JPasswordField();
        JButton loginBtn = new JButton("Login");

        userLabel.setBounds(30, 30, 100, 30);
        passLabel.setBounds(30, 70, 100, 30);
        userField.setBounds(120, 30, 150, 30);
        passField.setBounds(120, 70, 150, 30);
        loginBtn.setBounds(120, 110, 100, 30);

        loginBtn.addActionListener(e -> authenticateAdmin());
         

        add(userLabel); add(userField);
        add(passLabel); add(passField);
        add(loginBtn);

        setSize(350, 200);
        setLayout(null);
        setVisible(true);
    }

    void authenticateAdmin() {
        String user = userField.getText();
        String pass = new String(passField.getPassword());

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi")) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM admin WHERE username=? AND password=?");
            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login successful");
                new AdminDashboard();
                this.dispose();
                // Optionally show admin dashboard
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
    

