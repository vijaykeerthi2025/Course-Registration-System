/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
 import javax.swing.*;
public class ImageTest extends JFrame {
   

 

    public ImageTest() {
        setTitle("Image Test");
        setSize(400, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            // Try loading image from resources
            ImageIcon icon = new ImageIcon(getClass().getResource("/Icons/Cprogramming.png"));
            JLabel imageLabel = new JLabel(icon);
            imageLabel.setBounds(50, 50, 200, 100);
            add(imageLabel);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Image not found or failed to load");
            e.printStackTrace();
        }

        setVisible(true);
    }

    public static void main(String[] args) {
        new ImageTest();
    }
}
    

