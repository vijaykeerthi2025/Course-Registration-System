/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
 import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
public class AdminView extends JFrame {
     JTable table;
    DefaultTableModel model;

    public AdminView() {
        setTitle("Registered Students and Courses");

        model = new DefaultTableModel(new String[]{"Student ID", "Name", "Email", "Course ID"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 500, 300);
        add(scrollPane);

        loadData();

        setSize(560, 380);
        setLayout(null);
        setVisible(true);
    }

    private void loadData() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi")) {
            String query = "SELECT s.student_id, s.name, s.email, sc.course_id " +
                           "FROM student s " +
                           "LEFT JOIN student_courses sc ON s.student_id = sc.student_id";

            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String sid = rs.getString("student_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String course = rs.getString("course_id");
                model.addRow(new Object[]{sid, name, email, course});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

