/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class CourseSelection extends JFrame {
    String studentId;
    ArrayList<JCheckBox> checkBoxList = new ArrayList<>();
    HashMap<String, JPanel> courseCardMap = new HashMap<>();

    public CourseSelection(String studentId) {
        this.studentId = studentId;
        setTitle("Select Courses");
        setLayout(new BorderLayout());

        JPanel coursePanel = new JPanel();
        coursePanel.setLayout(new BoxLayout(coursePanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(coursePanel);
        add(scrollPane, BorderLayout.CENTER);

        // Search Bar
        JPanel searchPanel = new JPanel();
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchPanel.add(new JLabel("Search Course:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        add(searchPanel, BorderLayout.NORTH);

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi")) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM courses");

            while (rs.next()) {
                String courseId = rs.getString("course_id");
                String title = rs.getString("course_name");
                String desc = rs.getString("description");
                String instructor = rs.getString("instructor");
                String duration = rs.getString("duration");
                String imagePath = rs.getString("image_path");

                JPanel card = new JPanel();
                card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                card.setLayout(new BorderLayout());
                card.setPreferredSize(new Dimension(500, 140));

                // Load image
                ImageIcon icon;
                try {
                    String imageFile = (imagePath != null && !imagePath.isEmpty()) ? imagePath : "default.png";
                    java.net.URL imageUrl = getClass().getResource("/Icons/" + imageFile);
                    if (imageUrl != null) {
                        icon = new ImageIcon(imageUrl);
                    } else {
                        icon = new ImageIcon(getClass().getResource("/Icons/default.png"));
                    }
                } catch (Exception e) {
                    icon = new ImageIcon();
                }

                JLabel imageLabel = new JLabel();
                if (icon.getImage() != null) {
                    imageLabel.setIcon(new ImageIcon(icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
                }

                JPanel infoPanel = new JPanel();
                infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                infoPanel.add(new JLabel("Title: " + title));
                infoPanel.add(new JLabel("Instructor: " + instructor));
                infoPanel.add(new JLabel("Duration: " + duration));
                infoPanel.add(new JLabel("Description: " + desc));

                JCheckBox selectBox = new JCheckBox("Select");
                selectBox.setActionCommand(courseId);
                checkBoxList.add(selectBox);
                infoPanel.add(selectBox);

                card.add(imageLabel, BorderLayout.WEST);
                card.add(infoPanel, BorderLayout.CENTER);

                coursePanel.add(card);
                courseCardMap.put(title.toLowerCase(), card); // store reference for search
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // Search functionality
        searchButton.addActionListener(e -> {
            String query = searchField.getText().trim().toLowerCase();
            if (query.isEmpty()) return;
            JPanel match = courseCardMap.get(query);
            if (match != null) {
                match.scrollRectToVisible(match.getBounds());
                match.setBackground(new Color(220, 255, 220));
            } else {
                JOptionPane.showMessageDialog(this, "Course not found!");
            }
        });

        JButton submit = new JButton("Submit");
        submit.addActionListener(e -> registerCourses());
        add(submit, BorderLayout.SOUTH);

        setSize(600, 600);
        setVisible(true);
    }

    private void registerCourses() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi")) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)");

            for (JCheckBox box : checkBoxList) {
                if (box.isSelected()) {
                    ps.setString(1, studentId);
                    ps.setString(2, box.getActionCommand());
                    ps.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(this, "Courses registered!");
            dispose();
            showLogoutForm(); // call logout form
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showLogoutForm() {
        JFrame logoutFrame = new JFrame("Logout");
        logoutFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logoutFrame.setSize(300, 150);
        logoutFrame.setLayout(new BorderLayout());

        JLabel msg = new JLabel("You have been logged out.", SwingConstants.CENTER);
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            logoutFrame.dispose();
            System.exit(0); // or redirect to login form if available
        });

        logoutFrame.add(msg, BorderLayout.CENTER);
        logoutFrame.add(okButton, BorderLayout.SOUTH);
        logoutFrame.setLocationRelativeTo(null);
        logoutFrame.setVisible(true);
    }
}