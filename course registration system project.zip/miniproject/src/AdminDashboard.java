/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author VIJAYAKUMAR K G
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class AdminDashboard extends JFrame {
    JPanel coursesPanel;
    JTextField searchField;

    public AdminDashboard() {
        setTitle("Admin Dashboard - Course Management");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        JButton addCourseBtn = new JButton("Add Course");
        JButton viewStudentsBtn = new JButton("View Registrations");
        searchField = new JTextField(20);
        JButton searchBtn = new JButton("Search");

        topPanel.add(addCourseBtn);
        topPanel.add(viewStudentsBtn);
        topPanel.add(new JLabel("Search: "));
        topPanel.add(searchField);
        topPanel.add(searchBtn);

        add(topPanel, BorderLayout.NORTH);

        coursesPanel = new JPanel();
        coursesPanel.setLayout(new GridLayout(0, 3, 10, 10));
        JScrollPane scrollPane = new JScrollPane(coursesPanel);
        add(scrollPane, BorderLayout.CENTER);

        addCourseBtn.addActionListener(e -> openCourseForm(null));
        viewStudentsBtn.addActionListener(e -> viewRegistrations());
        searchBtn.addActionListener(e -> loadCourses(searchField.getText()));

        loadCourses("");
        setVisible(true);
    }

    private void loadCourses(String keyword) {
        coursesPanel.removeAll();
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi");
            String query = "SELECT * FROM courses WHERE course_name LIKE ? OR instructor LIKE ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, "%" + keyword + "%");
            pst.setString(2, "%" + keyword + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String courseId = rs.getString("course_id");
                String imgPath = rs.getString("image_path");
                String courseName = rs.getString("course_name");
                String instructor = rs.getString("instructor");
                String duration = rs.getString("duration");
                String description = rs.getString("description");

                JPanel courseCard = new JPanel();
                courseCard.setLayout(new BoxLayout(courseCard, BoxLayout.Y_AXIS));
                courseCard.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                ImageIcon icon;
try {
    String imageFile = (imgPath != null && !imgPath.isEmpty()) ? imgPath : "default.png";
    java.net.URL imageUrl = getClass().getResource("/Icons/" + imageFile);
    if (imageUrl != null) {
        icon = new ImageIcon(imageUrl);
    } else {
        icon = new ImageIcon(getClass().getResource("/Icons/default.png")); // fallback
        System.err.println("Image not found: " + imageFile);
    }
} catch (Exception ex) {
    icon = new ImageIcon(); // empty fallback
    System.err.println("Error loading image: " + ex.getMessage());
}
               
                JLabel imgLabel = new JLabel(new ImageIcon(icon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH)));
                JLabel titleLabel = new JLabel("Course: " + courseName);
                JLabel idLabel = new JLabel("ID: " + courseId);
                JLabel instructorLabel = new JLabel("Instructor: " + instructor);
                JLabel durationLabel = new JLabel("Duration: " + duration);

                JButton editBtn = new JButton("Edit");
                JButton deleteBtn = new JButton("Delete");

                editBtn.addActionListener(e -> openCourseForm(courseId));
                deleteBtn.addActionListener(e -> deleteCourse(courseId));

                courseCard.add(imgLabel);
                courseCard.add(titleLabel);
                courseCard.add(idLabel);
                courseCard.add(instructorLabel);
                courseCard.add(durationLabel);
                courseCard.add(editBtn);
                courseCard.add(deleteBtn);

                courseCard.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        JOptionPane.showMessageDialog(null, description, courseName + " - Details", JOptionPane.INFORMATION_MESSAGE);
                    }
                });

                coursesPanel.add(courseCard);
            }

            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        coursesPanel.revalidate();
        coursesPanel.repaint();
    }

    private void openCourseForm(String courseId) {
        JDialog dialog = new JDialog(this, "Course Form", true);
        dialog.setSize(400, 400);
        dialog.setLayout(new GridLayout(7, 2));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField instructorField = new JTextField();
        JTextField durationField = new JTextField();
        JTextField imagePathField = new JTextField();
        JTextArea descArea = new JTextArea();
        JButton saveBtn = new JButton("Save");

        dialog.add(new JLabel("Course ID:")); dialog.add(idField);
        dialog.add(new JLabel("Course Name:")); dialog.add(nameField);
        dialog.add(new JLabel("Instructor:")); dialog.add(instructorField);
        dialog.add(new JLabel("Duration:")); dialog.add(durationField);
        dialog.add(new JLabel("Image Path:")); dialog.add(imagePathField);
        dialog.add(new JLabel("Description:")); dialog.add(new JScrollPane(descArea));
        dialog.add(saveBtn);

        if (courseId != null) {
            idField.setEnabled(false);
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi");
                PreparedStatement pst = con.prepareStatement("SELECT * FROM courses WHERE course_id = ?");
                pst.setString(1, courseId);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    idField.setText(rs.getString("course_id"));
                    nameField.setText(rs.getString("course_name"));
                    instructorField.setText(rs.getString("instructor"));
                    durationField.setText(rs.getString("duration"));
                    imagePathField.setText(rs.getString("image_path"));
                    descArea.setText(rs.getString("description"));
                }
                con.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }

        saveBtn.addActionListener(e -> {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi");
                String query = (courseId == null) ?
                        "INSERT INTO courses(course_id, course_name, instructor, duration, image_path, description) VALUES(?,?,?,?,?,?)" :
                        "UPDATE courses SET course_name=?, instructor=?, duration=?, image_path=?, description=? WHERE course_id=?";
                PreparedStatement pst = con.prepareStatement(query);

                if (courseId == null) {
                    pst.setString(1, idField.getText());
                    pst.setString(2, nameField.getText());
                    pst.setString(3, instructorField.getText());
                    pst.setString(4, durationField.getText());
                    pst.setString(5, imagePathField.getText());
                    pst.setString(6, descArea.getText());
                } else {
                    pst.setString(1, nameField.getText());
                    pst.setString(2, instructorField.getText());
                    pst.setString(3, durationField.getText());
                    pst.setString(4, imagePathField.getText());
                    pst.setString(5, descArea.getText());
                    pst.setString(6, courseId);
                }

                pst.executeUpdate();
                con.close();
                dialog.dispose();
                loadCourses("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        dialog.setVisible(true);
    }

    private void deleteCourse(String courseId) {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this course?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi");
                PreparedStatement pst = con.prepareStatement("DELETE FROM courses WHERE course_id = ?");
                pst.setString(1, courseId);
                pst.executeUpdate();
                con.close();
                loadCourses("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    private void viewRegistrations() {
        JFrame tableFrame = new JFrame("Student Registrations");
        tableFrame.setSize(600, 400);

        String[] columnNames = {"Student ID", "Name", "Email", "Course"};
        ArrayList<String[]> data = new ArrayList<>();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "keerthi");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                "SELECT s.student_id, s.name, s.email, c.course_name " +
                "FROM student s " +
                "JOIN student_courses r ON s.student_id = r.student_id " +
                "JOIN courses c ON r.course_id = c.course_id");

            while (rs.next()) {
                data.add(new String[]{
                        rs.getString("student_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("course_name")
                });
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }

        String[][] tableData = new String[data.size()][];
        JTable table = new JTable(data.toArray(tableData), columnNames);
        tableFrame.add(new JScrollPane(table));
        tableFrame.setVisible(true);
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }
}